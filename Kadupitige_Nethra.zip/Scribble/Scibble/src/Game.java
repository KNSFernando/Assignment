import javax.swing.*;
import java.util.Scanner;
/**
 * A class that contains the game.
 *
 * @author K.N.S.Fernando
 * @version 1942
 * */
public class Game extends Table
{
    public static void main(String[] args)
    {
        System.out.println("Welcome to Scribble!!");
        System.out.println(" ");
        System.out.println("What would you like to do?");
        System.out.println("**(Please enter the number which corresponds with your choice)**");
        System.out.println(" ");
        System.out.println("1.Start a new Game");
        System.out.println("2.Load a Game");
        System.out.println("3.Quit");
        System.out.println(" ");

        Scanner w = new Scanner(System.in);
        int welcome = w.nextInt();

        if(welcome == 1)
        {
            System.out.println(" ");
            System.out.println("You have chosen to start a new game!!");
            System.out.println(" ");
            System.out.println("How many players will be playing?");
            System.out.println("1. Two PLayers");
            System.out.println("2. Four Players");
            System.out.println(" ");
            System.out.println("=================================================IMPORTANT=================================================");
            System.out.println("** The order of the game is according to the ascending order of the player number **");
            System.out.println("** The first one to play will be player 1 followed by player 2 and so on **");
            System.out.println("** At least one of the letters of a new word must contain at least one letter of an already existing word (This is not the case at the start of the game) **");
            System.out.println("** The new word must be built off of an already existing letter (This is not the case at the start of the game) **");
            System.out.println("** At the start of the game player 1 must place a word through the middle of the table (Through the column and row 15) **");
            System.out.println("** The first word must be at least 2 letters long **");
            System.out.println("=================================================IMPORTANT=================================================");

            Scanner pl =new Scanner(System.in);
            int pln=pl.nextInt();

            if(pln == 1 )
            {

                System.out.println(" ");
                System.out.println("Setting up 2 players...");
                System.out.println(" ");

                System.out.println("Player 1 please enter your name..");

                Scanner player =new Scanner(System.in);
                player1 = player.nextLine();
                player1Score = 0;

                System.out.println("Player 2 please enter your name..");
                player2 =player.nextLine();
                player2Score = 0;


                Table table = new Table();
                table.setup1(2);

            }

            else if(pln == 2)
            {
                System.out.println(" ");
                System.out.println("Setting up 4 players...");
                System.out.println(" ");

                System.out.println("Player 1 please enter your name..");

                Scanner player =new Scanner(System.in);
                player1 = player.nextLine();
                player1Score = 0;

                System.out.println("Player 2 please enter your name..");
                player2 =player.nextLine();
                player2Score = 0;

                System.out.println("Player 3 please enter your name..");
                player3 =player.nextLine();
                player3Score = 0;

                System.out.println("Player 4 please enter your name..");
                player4 =player.nextLine();
                player4Score = 0;


                Table table = new Table();
                table.setup1(4);

            }

        }
        else if (welcome == 2)
        {
            System.out.println(" ");
            System.out.println("Loading...");
            System.out.println(" ");

            System.out.println("How many players were playing the game?");
            System.out.println("** Please enter the number of players who were playing the game **");

            Scanner plcount = new Scanner(System.in);
            int playercount= plcount.nextInt();

            if(playercount == 2)
            {
                System.out.println(" ");
                System.out.println("Please enter the name of the save game...");
                System.out.println("=================================================IMPORTANT=================================================");
                System.out.println("**                              Please enter .txt at the end of the name                                  **");
                System.out.println("=================================================IMPORTANT=================================================");

                Scanner s = new Scanner(System.in);
                String saveGame =s.nextLine();

                Table table = new Table();
                table.load(saveGame);

                table.display();

                table.loadsetup2();
            }

            else if (playercount == 4);
            {
                System.out.println(" ");
                System.out.println("Please enter the name of the save game...");
                System.out.println("=================================================IMPORTANT=================================================");
                System.out.println("**                              Please enter .txt at the end of the name                                  **");
                System.out.println("=================================================IMPORTANT=================================================");

                Scanner s = new Scanner(System.in);
                String saveGame =s.nextLine();

                Table table = new Table();
                table.load(saveGame);

                table.display();

                table.loadsetup4();
            }

        }

        else if(welcome == 3)
        {
            System.out.println(" ");
            System.out.println("Thank you for playing our game!!");
            System.out.println("Have a great day!!!");
            System.exit(0);
        }
    }


}
