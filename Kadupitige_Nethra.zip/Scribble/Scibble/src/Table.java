import java.io.*;
import java.util.Scanner;

/**
 * A class that stores and works with the details of the table.
 *
 * @author K.N.S.Fernando
 * @version 1936
 * */
public class Table
{

    String [][] letter = new String[15][15];

    public static String player1;
    public static String player2;
    public static String player3;
    public static String player4;

    public static String currentPlayer;

    public static int player1Score;
    public static int player2Score;
    public static int player3Score;
    public static int player4Score;

    /**
     * The constructor method that sets all the values in the array to '.'.
     * */
    public void set()
    {
        for (int i =0;i<letter.length;i++)
        {
            for(int j =0;j<letter.length;j++)
            {
                letter [i][j]= ".";

            }

        }
    }

    /**
     * Displays the Scribble table.
     * */
    public void display()
    {
        char [] a2o = {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O'};


        System.out.println(" ");
        System.out.print("| . |  ");

        for(int i =0; i<15;i++)
        {
            System.out.print("| "+ a2o [i]+" |");
        }
        System.out.println(" ");

        System.out.println("=========================================================================================");

        for(int i =0; i<15;i++)
        {
            System.out.print("| "+ a2o [i]+" |  ");


            for(int j=0;j<15;j++)
            {
                System.out.print("| "+ letter[i][j]+" |");

            }
            System.out.println(" ");
        }

    }

    /**
     * Gives the instructions/rules of the game to the player
     * */
    public  void giveInstructions()
    {
        System.out.println("================================ Game instructions ================================");
        System.out.println(" ");
        System.out.println("** The order of the game is according to the ascending order of the player number **");
        System.out.println("** The first one to play will be player 1 followed by player 2 and so on **");
        System.out.println("** At least one of the letters of a new word must contain at least one letter of an already existing word (This is not the case at the start of the game) **");
        System.out.println("** The new word must be built off of an already existing letter (This is not the case at the start of the game) **");
        System.out.println("** At the start of the game player 1 must place a word through the middle of the table (Through the column and row 15) **");
        System.out.println("** The first word must be at least 2 letters long **");
        System.out.println("** Write the word in simple letters **");
        System.out.println("** The first player to reach 100 points shall win the game **");
        System.out.println("** The game may end when all players have had 200 turns of the game **");
        System.out.println("** If the game ends without anyone reaching 100 points, the player with the most points shall win the game **");
        System.out.println(" ");
        System.out.println("================================ Game instructions ================================");
    }

    /**
     * Calculates the score.
     * @param letter the letter to which a score should be assigned to.
     * */
    public static int getScore(String letter)
    {
        if(letter.equals("a")||letter.equals("e")||letter.equals("i")||letter.equals("o")||letter.equals("u")||letter.equals("l")||letter.equals("n")||letter.equals("s")||letter.equals("t")||letter.equals("r"))
        {
            return 1;
        }

        else if(letter.equals("d")||letter.equals("g"))
        {
            return 2;
        }

        else if(letter.equals("b")||letter.equals("c")||letter.equals("m")||letter.equals("p"))
        {
            return 3;
        }

        else if(letter.equals("f")||letter.equals("h")||letter.equals("v")||letter.equals("w")||letter.equals("y"))
        {
            return 4;
        }

        else if(letter.equals("k"))
        {
            return 5;
        }

        else if(letter.equals("j")||letter.equals("x"))
        {
            return 8;
        }

        else if(letter.equals("q")||letter.equals("z"))
        {
            return 10;
        }

        else
        {
            return 0;
        }

    }

    /**
     * Saves the game as a file on disk. Allows the user to give a name to the save file.
     * */
    public void save()
    {
        System.out.println("Please give the name of the file to which the table of expenditure should be saved as.");
        System.out.println("=================================================IMPORTANT=================================================");
        System.out.println("**                              Please enter .txt at the end of the name                                  **");
        System.out.println("=================================================IMPORTANT=================================================");
        System.out.println(" ");

        Scanner fileOutPut = new Scanner(System.in);
        String nameOfFile = fileOutPut.nextLine();

        FileOutputStream outputStream = null;
        PrintWriter printWriter = null;

        try
        {

            outputStream = new FileOutputStream(nameOfFile);
            printWriter = new PrintWriter(outputStream);

            for (int i =0;i<letter.length;i++)
            {
                for(int j =0;j<letter.length;j++)
                {
                    printWriter.print(letter[i][j]+",");
                }

                printWriter.println(" ");

            }

            printWriter.println(currentPlayer);
            printWriter.println(player1);
            printWriter.println(player1Score);
            printWriter.println(player2);
            printWriter.println(player2Score);
            printWriter.println(player3);
            printWriter.println(player3Score);
            printWriter.println(player4);
            printWriter.println(player4Score);

        }

        catch(IOException e)
        {
            System.out.println("Sorry, there has been a problem opening the file or writing to the file.");
        }

        finally
        {
            if (printWriter != null)
                printWriter.close();
        }

    }

    /**
     * Loads the game from a file on disk. Only works if two players were playing the game.
     * @param fileName the name of the save file from which to load the content from.
     * */
    public String [] [] load(String fileName)
    {
        FileReader fileReader = null;
        BufferedReader bufferedReader = null;
        String nextLine;

        try
        {
            fileReader = new FileReader(fileName);
            bufferedReader = new BufferedReader(fileReader);
            nextLine = bufferedReader.readLine();



            for(int i = 0; i < letter.length; i++)
            {
                String [] tableLetters = nextLine.split(",");
                letter [i][0] = tableLetters [0];
                letter [i][1] = tableLetters [1];
                letter [i][2] = tableLetters [2];
                letter [i][3] = tableLetters [3];
                letter [i][4] = tableLetters [4];
                letter [i][5] = tableLetters [5];
                letter [i][6] = tableLetters [6];
                letter [i][7] = tableLetters [7];
                letter [i][8] = tableLetters [8];
                letter [i][9] = tableLetters [9];
                letter [i][10] = tableLetters [10];
                letter [i][11] = tableLetters [11];
                letter [i][12] = tableLetters [12];
                letter [i][13] = tableLetters [13];
                letter [i][14] = tableLetters [14];
                nextLine = bufferedReader.readLine();
            }

            currentPlayer = nextLine;
            nextLine = bufferedReader.readLine();

            player1 = nextLine;
            nextLine = bufferedReader.readLine();

            int realscore1 = Integer.parseInt(nextLine);
            player1Score = realscore1;
            nextLine = bufferedReader.readLine();

            player2 = nextLine;
            nextLine = bufferedReader.readLine();

            int realscore2 = Integer.parseInt(nextLine);
            player2Score = realscore2;
            nextLine = bufferedReader.readLine();

            player3 = nextLine;
            nextLine = bufferedReader.readLine();

            int realscore3 = Integer.parseInt(nextLine);
            player3Score = realscore3;
            nextLine = bufferedReader.readLine();

            player4 = nextLine;
            nextLine = bufferedReader.readLine();

            int realscore4 = Integer.parseInt(nextLine);
            player4Score = realscore4;

        }
        catch (IOException e)
        {
            System.out.println(" ");
            System.out.println("Sorry, there has been a problem opening the file.");
        }

        finally
        {
            if (bufferedReader != null)
            {
                try
                {
                    bufferedReader.close();
                }
                catch (IOException e)
                {
                    System.out.println("Sorry, there has been a problem closing the file");
                }

            }

        }

        return letter;

    }

    /**
     * Checks if the word is a valid word in a file called Oxford.txt .
     * @param word the word that needs to be checked.
     * */
    public static void checkWord(String word) {

        FileReader fileReader = null;
        BufferedReader bufferedReader = null;
        String nextLine;

        String fileName = "Oxford.txt";

        try
        {
            fileReader = new FileReader(fileName);
            bufferedReader = new BufferedReader(fileReader);
            nextLine = bufferedReader.readLine();

            boolean found = false;
            while(nextLine != null)
            {
                if(nextLine.equals(word))
                {
                    found = true;
                    break;
                }

                nextLine = bufferedReader.readLine();
            }

            if(found)
            {
                System.out.println(" ");
                System.out.println("The word you entered is a real word!!");
                System.out.println("All good.");
                System.out.println(" ");
            }

            else {

                System.out.println(" ");
                System.out.println("The word you entered wasn't found in our database of the english dictionary.");
                System.out.println("But I will give you the benefit of the doubt.");
                System.out.println(" ");
            }
        }


        catch (IOException e) {
            System.out.println(" ");
            System.out.println("Sorry, there has been a problem opening the file.");
            System.out.println(" ");
        }

        finally

        {
            if (bufferedReader != null) {
                try {
                    bufferedReader.close();
                } catch (IOException e) {
                    System.out.println("Sorry, there has been a problem closing the file");
                }

            }

        }

    }

    /**
     * Checks if the word entered by the user conforms to the rules of Scribble (i.e. checks if the word contains a letter that's already in the table and if i inside the boundaries of the table.)
     * @param wordLetter the letter to be checked.
     * @param row the row of the letter array that needs to be checked.
     * @param column the column of the letter array that need to be checked.
     * @param direction the direction of the word that the user wishes to add the letter.
     * */
    public  boolean checkValid(String [] wordLetter, int row, int column,String direction)
    {

        if(direction.equalsIgnoreCase("V"))
        {
            if ((wordLetter.length + row) > letter.length)
            {
                System.out.println(" ");
                System.out.println("================================================= WARNING =================================================");
                System.out.println("**                  Sorry the word you entered goes beyond the boundary of the table!!                   **");
                System.out.println("================================================= WARNING =================================================");
                System.out.println(" ");
                return false;
            }

            for (int i = 0; row + i < letter.length && i < wordLetter.length; i++)
            {
                if (letter[row + i][column] != null && letter[row + i][column].equals(wordLetter[i]))
                {
                    System.out.println(" ");
                    System.out.println("All good.");
                    System.out.println(" ");

                    return true;
                }
            }

            System.out.println(" ");
            System.out.println("================================================= WARNING =================================================");
            System.out.println("**                                  Sorry the word you entered isn't valid!!                             **");
            System.out.println("**                                          PLEASE TRY AGAIN !!                                          **");
            System.out.println("================================================= WARNING =================================================");
            System.out.println(" ");
        }

        else if(direction.equalsIgnoreCase("H"))
        {
            if ((wordLetter.length + column) > letter.length)
            {
                System.out.println(" ");
                System.out.println("================================================= WARNING =================================================");
                System.out.println("**                  Sorry the word you entered goes beyond the boundary of the table!!                   **");
                System.out.println("================================================= WARNING =================================================");
                System.out.println(" ");
                return false;
            }

            for (int i = 0; column + i < letter[0].length && i < wordLetter.length; i++)
            {
                if (letter[row][column + i] != null && letter[row][column + i].equals(wordLetter[i]))
                {
                    System.out.println(" ");
                    System.out.println("All good.");
                    System.out.println(" ");
                    return true;
                }
            }

            System.out.println(" ");
            System.out.println("================================================= WARNING =================================================");
            System.out.println("**                                  Sorry the word you entered isn't valid!!                             **");
            System.out.println("**                                          PLEASE TRY AGAIN !!                                          **");
            System.out.println("================================================= WARNING =================================================");
            System.out.println(" ");
        }

        return false;

    }

    /**
     * Allows the first player to take his turn.
     * */
    public void turnPlayer1()
    {
        boolean nextTurn = false;

        while (!nextTurn)
        {

            System.out.println(" ");
            System.out.println("================== " + player1 + "'s Turn " + "==================");
            System.out.println("Your score is " + player1Score);
            System.out.println("What would you like to do?");
            System.out.println(" ");
            System.out.println("1.Add a word");
            System.out.println("2.Open the menu");
            System.out.println("3.Quit");

            Scanner choice2 = new Scanner(System.in);
            int ans2 = choice2.nextInt();

            if (ans2 == 1) {
                System.out.println(" ");
                System.out.println("Please enter the word you wish to add to the table.");
                System.out.println(" ");
                System.out.println("=================================================IMPORTANT=================================================");
                System.out.println("**Write the word in simple letters**");
                System.out.println("**The first letter of your world will start from the coordinates you enter (row,column)**");
                System.out.println("=================================================IMPORTANT=================================================");


                Scanner w1 = new Scanner(System.in);
                String word1 = w1.nextLine();
                String[] parts = word1.split("");

                checkWord(word1);

                System.out.println("Do you wish to enter the word vertically or horizontally?");
                System.out.println("**Please enter V or H (V - Vertical  H- Horizontal)**");

                Scanner vh = new Scanner(System.in);
                String verhor = vh.nextLine();

                if ((verhor.equals("V")) || (verhor.equals("v"))) {
                    System.out.println("Please enter the X and Y coordinates where you wish to enter your first letter of your word");
                    System.out.println("=================================================IMPORTANT=================================================");
                    System.out.println("** A=0 B=1 C=2 D=3 E=4 F=5 G=6 H=7 I=8 J=9 K=10 L=11 M=12 N=13 O=14 **");
                    System.out.println("=================================================IMPORTANT=================================================");

                    System.out.println(" ");
                    System.out.println("Row: ");
                    Scanner row = new Scanner(System.in);
                    int x = row.nextInt();

                    System.out.println(" ");
                    System.out.println("Column: ");
                    Scanner column = new Scanner(System.in);
                    int y = column.nextInt();

                    boolean ok = checkValid(parts,x,y,"V");

                    if(ok == true)
                    {
                        int j = x;
                        for (int i = 0; i < parts.length; i++)
                        {
                            letter[j][y] = parts[i];
                            j++;
                        }

                        for (int i = 0; i < parts.length; i++) {
                            player1Score += getScore(parts[i]);
                        }

                        nextTurn=true;

                        display();
                    }
                } else if ((verhor.equals("H")) || (verhor.equals("h"))) {
                    System.out.println("Please enter the X and Y coordinates where you wish to enter your first letter of your word");
                    System.out.println("=================================================IMPORTANT=================================================");
                    System.out.println("**A=0 B=1 C=2 D=3 E=4 F=5 G=6 H=7 I=8 J=9 K=10 L=11 M=12 N=13 O=14**");
                    System.out.println("=================================================IMPORTANT=================================================");

                    System.out.println(" ");
                    System.out.println("Row: ");
                    Scanner row = new Scanner(System.in);
                    int x = row.nextInt();

                    System.out.println(" ");
                    System.out.println("Column: ");
                    Scanner column = new Scanner(System.in);
                    int y = column.nextInt();

                    boolean ok = checkValid(parts,x,y,"H");

                    if(ok == true)
                    {
                        int j = y;
                        for (int i = 0; i < parts.length; i++) {
                            letter[x][j] = parts[i];
                            j++;
                        }

                        for (int i = 0; i < parts.length; i++) {
                            player1Score += getScore(parts[i]);
                        }

                        nextTurn=true;

                        display();

                    }
                }

            }

            else if (ans2 == 2)
            {
                boolean menuback = false;
                while (!menuback) {
                    System.out.println(" ");
                    System.out.println("What would you like to do?");
                    System.out.println(" ");
                    System.out.println("1.See game instructions");
                    System.out.println("2.Save game");
                    System.out.println("3.Go back");

                    Scanner choice = new Scanner(System.in);
                    int menuChoice = choice.nextInt();

                    if (menuChoice == 1) {
                        giveInstructions();
                    } else if (menuChoice == 2) {
                        currentPlayer = player1;

                        save();

                        System.out.println("Game Saved");
                        System.out.println("Returning to the previous menu...");
                        System.out.println(" ");
                        menuback = true;

                    } else if (menuChoice == 3) {
                        System.out.println("Returning to the previous menu...");
                        System.out.println(" ");
                        menuback = true;

                    } else {
                        System.out.println(" ");
                        System.out.println("Invalid choice");
                        System.out.println("Please try again");

                    }
                }

            } else if (ans2 == 3) {
                System.out.println(" ");
                System.out.println("Closing the game...");
                System.out.println("Thank you for playing our game!!");
                System.out.println("Have a great day!!!");

                System.exit(0);
            }

        }
    }

    /**
     * Allows the second player to take his turn.
     * */
    public void turnPlayer2()
    {
        boolean nextTurn = false;

        while (!nextTurn)
        {
            System.out.println(" ");
            System.out.println("================== " + player2 + "'s Turn " + "==================");
            System.out.println("Your score is " + player2Score);
            System.out.println("What would you like to do?");
            System.out.println(" ");

            System.out.println("1.Add a word");
            System.out.println("2.Open the menu");
            System.out.println("3.Quit");

            Scanner choice = new Scanner(System.in);
            int ans = choice.nextInt();

            if (ans == 1) {
                System.out.println(" ");
                System.out.println("Please enter the word you wish to add to the table.");
                System.out.println(" ");
                System.out.println("================================================= IMPORTANT =================================================");
                System.out.println("**Write the word in simple letters**");
                System.out.println("**The first letter of your world will start from the coordinates you enter (row,column)**");
                System.out.println("================================================= IMPORTANT =================================================");


                Scanner w1 = new Scanner(System.in);
                String word1 = w1.nextLine();
                String[] parts = word1.split("");

                checkWord(word1);

                System.out.println("Do you wish to enter the word vertically or horizontally?");
                System.out.println("**Please enter V or H (V - Vertical  H- Horizontal)**");

                Scanner vh = new Scanner(System.in);
                String verhor = vh.nextLine();

                if ((verhor.equals("V")) || (verhor.equals("v"))) {
                    System.out.println("Please enter the X and Y coordinates where you wish to enter your first letter of your word");
                    System.out.println("================================================= IMPORTANT =================================================");
                    System.out.println("** A=0 B=1 C=2 D=3 E=4 F=5 G=6 H=7 I=8 J=9 K=10 L=11 M=12 N=13 O=14 **");
                    System.out.println("================================================= IMPORTANT =================================================");

                    System.out.println(" ");
                    System.out.println("Row: ");
                    Scanner row = new Scanner(System.in);
                    int x = row.nextInt();

                    System.out.println(" ");
                    System.out.println("Column: ");
                    Scanner column = new Scanner(System.in);
                    int y = column.nextInt();

                    boolean ok = checkValid(parts,x,y,"V");

                    if(ok == true)
                    {
                        int j = x;
                        for (int i = 0; i < parts.length; i++)
                        {
                            letter[j][y] = parts[i];
                            j++;
                        }

                        for (int i = 0; i < parts.length; i++) {
                            player2Score += getScore(parts[i]);
                        }

                        nextTurn=true;

                        display();

                    }
                } else if ((verhor.equals("H")) || (verhor.equals("h"))) {
                    System.out.println("Please enter the X and Y coordinates where you wish to enter your first letter of your word");
                    System.out.println("================================================= IMPORTANT =================================================");
                    System.out.println("**A=0 B=1 C=2 D=3 E=4 F=5 G=6 H=7 I=8 J=9 K=10 L=11 M=12 N=13 O=14**");
                    System.out.println("================================================= IMPORTANT =================================================");

                    System.out.println(" ");
                    System.out.println("Row: ");
                    Scanner row = new Scanner(System.in);
                    int x = row.nextInt();

                    System.out.println(" ");
                    System.out.println("Column: ");
                    Scanner column = new Scanner(System.in);
                    int y = column.nextInt();

                    boolean ok = checkValid(parts,x,y,"H");

                    if(ok == true)
                    {
                        int j = y;
                        for (int i = 0; i < parts.length; i++) {
                            letter[x][j] = parts[i];
                            j++;
                        }

                        for (int i = 0; i < parts.length; i++) {
                            player2Score += getScore(parts[i]);
                        }

                        nextTurn=true;

                        display();

                    }

                }


            } else if (ans == 2) {
                boolean menuback = false;
                while (!menuback) {
                    System.out.println(" ");
                    System.out.println("What would you like to do?");
                    System.out.println(" ");
                    System.out.println("1.See game instructions");
                    System.out.println("2.Save game");
                    System.out.println("3.Go back");

                    int menuChoice = choice.nextInt();

                    if (menuChoice == 1) {
                        giveInstructions();
                    } else if (menuChoice == 2) {
                        currentPlayer = player2;
                        save();

                        System.out.println("Game Saved");
                        System.out.println("Returning to the previous menu...");
                        System.out.println(" ");
                        menuback = true;
                    } else if (menuChoice == 3) {
                        System.out.println("Returning to the previous menu...");
                        System.out.println(" ");
                        menuback = true;
                    }

                    else
                    {
                        System.out.println(" ");
                        System.out.println("Invalid choice");
                        System.out.println("Please try again");

                    }
                }

            }

            else if (ans == 3) {
                System.out.println(" ");
                System.out.println("Closing the game...");
                System.out.println("Thank you for playing our game!!");
                System.out.println("Have a great day!!!");

                System.exit(0);
            }
        }
    }

    /**
     * Allows the third player to take his turn.
     * */
    public void turnPlayer3()
    {
        boolean nextTurn = false;

        while (!nextTurn)
        {
            System.out.println(" ");
            System.out.println("================== " + player3 + "'s Turn " + "==================");
            System.out.println("Your score is " + player3Score);
            System.out.println("What would you like to do?");
            System.out.println(" ");

            System.out.println("1.Add a word");
            System.out.println("2.Open the menu");
            System.out.println("3.Quit");

            Scanner choice = new Scanner(System.in);
            int ans = choice.nextInt();

            if (ans == 1) {
                System.out.println(" ");
                System.out.println("Please enter the word you wish to add to the table.");
                System.out.println(" ");
                System.out.println("================================================= IMPORTANT =================================================");
                System.out.println("**Write the word in simple letters**");
                System.out.println("**The first letter of your world will start from the coordinates you enter (row,column)**");
                System.out.println("================================================= IMPORTANT =================================================");


                Scanner w1 = new Scanner(System.in);
                String word1 = w1.nextLine();
                String[] parts = word1.split("");

                checkWord(word1);

                System.out.println("Do you wish to enter the word vertically or horizontally?");
                System.out.println("**Please enter V or H (V - Vertical  H- Horizontal)**");

                Scanner vh = new Scanner(System.in);
                String verhor = vh.nextLine();

                if ((verhor.equals("V")) || (verhor.equals("v"))) {
                    System.out.println("Please enter the X and Y coordinates where you wish to enter your first letter of your word");
                    System.out.println("================================================= IMPORTANT =================================================");
                    System.out.println("** A=0 B=1 C=2 D=3 E=4 F=5 G=6 H=7 I=8 J=9 K=10 L=11 M=12 N=13 O=14 **");
                    System.out.println("================================================= IMPORTANT =================================================");

                    System.out.println(" ");
                    System.out.println("Row: ");
                    Scanner row = new Scanner(System.in);
                    int x = row.nextInt();

                    System.out.println(" ");
                    System.out.println("Column: ");
                    Scanner column = new Scanner(System.in);
                    int y = column.nextInt();

                    boolean ok = checkValid(parts,x,y,"V");

                    if(ok == true)
                    {
                        int j = x;
                        for (int i = 0; i < parts.length; i++)
                        {
                            letter[j][y] = parts[i];
                            j++;
                        }

                        for (int i = 0; i < parts.length; i++) {
                            player3Score += getScore(parts[i]);
                        }

                        nextTurn=true;

                        display();

                    }
                } else if ((verhor.equals("H")) || (verhor.equals("h"))) {
                    System.out.println("Please enter the X and Y coordinates where you wish to enter your first letter of your word");
                    System.out.println("================================================= IMPORTANT =================================================");
                    System.out.println("**A=0 B=1 C=2 D=3 E=4 F=5 G=6 H=7 I=8 J=9 K=10 L=11 M=12 N=13 O=14**");
                    System.out.println("================================================= IMPORTANT =================================================");

                    System.out.println(" ");
                    System.out.println("Row: ");
                    Scanner row = new Scanner(System.in);
                    int x = row.nextInt();

                    System.out.println(" ");
                    System.out.println("Column: ");
                    Scanner column = new Scanner(System.in);
                    int y = column.nextInt();

                    boolean ok = checkValid(parts,x,y,"H");

                    if(ok == true)
                    {
                        int j = y;
                        for (int i = 0; i < parts.length; i++) {
                            letter[x][j] = parts[i];
                            j++;
                        }

                        for (int i = 0; i < parts.length; i++) {
                            player3Score += getScore(parts[i]);
                        }

                        nextTurn=true;

                        display();

                    }

                }


            } else if (ans == 2) {
                boolean menuback = false;
                while (!menuback) {
                    System.out.println(" ");
                    System.out.println("What would you like to do?");
                    System.out.println(" ");
                    System.out.println("1.See game instructions");
                    System.out.println("2.Save game");
                    System.out.println("3.Go back");

                    int menuChoice = choice.nextInt();

                    if (menuChoice == 1) {
                        giveInstructions();
                    } else if (menuChoice == 2) {
                        currentPlayer = player3;
                        save();

                        System.out.println("Game Saved");
                        System.out.println("Returning to the previous menu...");
                        System.out.println(" ");
                        menuback = true;
                    } else if (menuChoice == 3) {
                        System.out.println("Returning to the previous menu...");
                        System.out.println(" ");
                        menuback = true;
                    }

                    else
                    {
                        System.out.println(" ");
                        System.out.println("Invalid choice");
                        System.out.println("Please try again");

                    }
                }

            }

            else if (ans == 3) {
                System.out.println(" ");
                System.out.println("Closing the game...");
                System.out.println("Thank you for playing our game!!");
                System.out.println("Have a great day!!!");

                System.exit(0);
            }

        }
    }

    /**
     * Allows the fourth player to take his turn.
     * */
    public void turnPlayer4()
    {
        boolean nextTurn = false;

        while (!nextTurn)
        {
            System.out.println(" ");
            System.out.println("================== " + player4 + "'s Turn " + "==================");
            System.out.println("Your score is " + player4Score);
            System.out.println("What would you like to do?");
            System.out.println(" ");

            System.out.println("1.Add a word");
            System.out.println("2.Open the menu");
            System.out.println("3.Quit");

            Scanner choice = new Scanner(System.in);
            int ans = choice.nextInt();

            if (ans == 1) {
                System.out.println(" ");
                System.out.println("Please enter the word you wish to add to the table.");
                System.out.println(" ");
                System.out.println("================================================= IMPORTANT =================================================");
                System.out.println("**Write the word in simple letters**");
                System.out.println("**The first letter of your world will start from the coordinates you enter (row,column)**");
                System.out.println("================================================= IMPORTANT =================================================");


                Scanner w1 = new Scanner(System.in);
                String word1 = w1.nextLine();
                String[] parts = word1.split("");

                checkWord(word1);

                System.out.println("Do you wish to enter the word vertically or horizontally?");
                System.out.println("**Please enter V or H (V - Vertical  H- Horizontal)**");

                Scanner vh = new Scanner(System.in);
                String verhor = vh.nextLine();

                if ((verhor.equals("V")) || (verhor.equals("v"))) {
                    System.out.println("Please enter the X and Y coordinates where you wish to enter your first letter of your word");
                    System.out.println("================================================= IMPORTANT =================================================");
                    System.out.println("** A=0 B=1 C=2 D=3 E=4 F=5 G=6 H=7 I=8 J=9 K=10 L=11 M=12 N=13 O=14 **");
                    System.out.println("================================================= IMPORTANT =================================================");

                    System.out.println(" ");
                    System.out.println("Row: ");
                    Scanner row = new Scanner(System.in);
                    int x = row.nextInt();

                    System.out.println(" ");
                    System.out.println("Column: ");
                    Scanner column = new Scanner(System.in);
                    int y = column.nextInt();

                    boolean ok = checkValid(parts,x,y,"V");

                    if(ok == true)
                    {
                        int j = x;
                        for (int i = 0; i < parts.length; i++)
                        {
                            letter[j][y] = parts[i];
                            j++;
                        }

                        for (int i = 0; i < parts.length; i++) {
                            player4Score += getScore(parts[i]);
                        }

                        nextTurn=true;

                        display();

                    }
                } else if ((verhor.equals("H")) || (verhor.equals("h"))) {
                    System.out.println("Please enter the X and Y coordinates where you wish to enter your first letter of your word");
                    System.out.println("================================================= IMPORTANT =================================================");
                    System.out.println("**A=0 B=1 C=2 D=3 E=4 F=5 G=6 H=7 I=8 J=9 K=10 L=11 M=12 N=13 O=14**");
                    System.out.println("================================================= IMPORTANT =================================================");

                    System.out.println(" ");
                    System.out.println("Row: ");
                    Scanner row = new Scanner(System.in);
                    int x = row.nextInt();

                    System.out.println(" ");
                    System.out.println("Column: ");
                    Scanner column = new Scanner(System.in);
                    int y = column.nextInt();

                    boolean ok = checkValid(parts,x,y,"H");

                    if(ok == true)
                    {
                        int j = y;
                        for (int i = 0; i < parts.length; i++) {
                            letter[x][j] = parts[i];
                            j++;
                        }

                        for (int i = 0; i < parts.length; i++) {
                            player4Score += getScore(parts[i]);
                        }

                        nextTurn=true;

                        display();

                    }

                }


            } else if (ans == 2) {
                boolean menuback = false;
                while (!menuback) {
                    System.out.println(" ");
                    System.out.println("What would you like to do?");
                    System.out.println(" ");
                    System.out.println("1.See game instructions");
                    System.out.println("2.Save game");
                    System.out.println("3.Go back");

                    int menuChoice = choice.nextInt();

                    if (menuChoice == 1) {
                        giveInstructions();
                    } else if (menuChoice == 2) {
                        currentPlayer = player4;
                        save();

                        System.out.println("Game Saved");
                        System.out.println("Returning to the previous menu...");
                        System.out.println(" ");
                        menuback = true;
                    } else if (menuChoice == 3) {
                        System.out.println("Returning to the previous menu...");
                        System.out.println(" ");
                        menuback = true;
                    }

                    else
                    {
                        System.out.println(" ");
                        System.out.println("Invalid choice");
                        System.out.println("Please try again");

                    }
                }

            }

            else if (ans == 3) {
                System.out.println(" ");
                System.out.println("Closing the game...");
                System.out.println("Thank you for playing our game!!");
                System.out.println("Have a great day!!!");

                System.exit(0);
            }

        }
    }

    /**
     * Allows the user to start up the game by placing a word in the middle of the table.
     * @param playernumber the number of players playing the game
     * */
    public void setup1(int playernumber)
    {
        set();
        display();
        boolean exit = false;

        while( (!exit) && (player1Score<=100) && (player2Score<=100) && (player3Score<=100) && (player4Score<=100) )
        {
            System.out.println(" ");
            System.out.println("================== " + player1 + "'s Turn " + "==================");
            System.out.println("Your score is "+ player1Score);
            System.out.println("What would you like to do?");
            System.out.println(" ");
            System.out.println("1.Start the game");
            System.out.println("2.Open the menu");
            System.out.println("3.Quit");

            Scanner choice = new Scanner(System.in);
            int ans = choice.nextInt();

            if (ans == 1)
            {
                System.out.println(" ");
                System.out.println("Please enter the word you wish to add to the table.");
                System.out.println(" ");
                System.out.println("=================================================IMPORTANT=================================================");
                System.out.println("**The word should be more than 2 letters long**");
                System.out.println("**Due this being the first word you will need to make sure that it doesn't contain more than 7 letters**");
                System.out.println("**Write the word in simple letters**");
                System.out.println("**The first letter of your world will start from the middle of the table (H,H)**");
                System.out.println("=================================================IMPORTANT=================================================");


                Scanner w1 = new Scanner(System.in);
                String word1 = w1.nextLine();

                checkWord(word1);

                String[] parts = word1.split("");

                while(parts.length<=2)
                {
                    System.out.println(" ");
                    System.out.println("You entered a word smaller than three letters!!!");
                    System.out.println("Please try again..");
                    System.out.println(" ");

                    word1 = w1.nextLine();

                    checkWord(word1);

                    parts = word1.split("");
                }

                while(parts.length>8)
                {
                    System.out.println("================================================= WARNING =================================================");
                    System.out.println("**Your word goes beyond the boundaries of the table**");
                    System.out.println("**Please try again**");
                    System.out.println("================================================= WARNING =================================================");

                    System.out.println(" ");
                    System.out.println("Please enter the word you wish to add to the table.");
                    System.out.println(" ");
                    System.out.println("================================================= IMPORTANT =================================================");
                    System.out.println("**The word should be more than 2 letters long**");
                    System.out.println("**Due this being the first word you will need to make sure that it doesn't contain more than 7 letters**");
                    System.out.println("**Write the word in simple letters**");
                    System.out.println("**The first letter of your world will start from the middle of the table (H,H)**");
                    System.out.println("================================================= IMPORTANT =================================================");

                    word1 = w1.nextLine();
                    parts = word1.split("");

                }

                for(int i = 0; i < parts.length; i++)
                {
                    player1Score += getScore(parts[i]);
                }

                System.out.println("Do you wish to enter the word vertically or horizontally?");
                System.out.println("**Please enter V or H (V - Vertical  H- Horizontal)**");

                Scanner vh = new Scanner(System.in);
                String verhor = vh.nextLine();


                if((verhor.equals("V"))||(verhor.equals("v")))
                {
                    int j=7;
                    for(int i = 0;i<parts.length;i++)
                    {
                        letter[j][7] = parts[i];
                        j++;
                    }
                }
                else if((verhor.equals("H"))||(verhor.equals("h")))
                {
                    int j=7;
                    for(int i = 0;i<parts.length;i++)
                    {
                        letter[7][j] = parts[i];
                        j++;
                    }
                }
                else
                {
                    System.out.println("You enter an incorrect value");
                    System.out.println("Please try again");

                    verhor = vh.nextLine();
                    if((verhor.equals("V"))||(verhor.equals("v")))
                    {
                        int j=7;
                        for (int i = 0;i<parts.length;i++)
                        {
                            letter[j][7] = parts[i];
                            j++;
                        }
                    }
                    else if((verhor.equals("H"))||(verhor.equals("h")))
                    {
                        int j=7;
                        for (int i = 0;i<parts.length;i++)
                        {
                            letter[7][j] = parts[i];
                            j++;
                        }
                    }
                }

                display();
                exit = true;
            }
            else if (ans == 2)
            {
                boolean menuback = false;
                while (!menuback)
                {
                    System.out.println(" ");
                    System.out.println("What would you like to do?");
                    System.out.println(" ");
                    System.out.println("1.See game instructions");
                    System.out.println("2.Save game");
                    System.out.println("3.Go back");

                    int menuChoice = choice.nextInt();

                    if (menuChoice == 1)
                    {
                        giveInstructions();
                    }

                    else if (menuChoice == 2)
                    {
                        currentPlayer = player1;
                        save();

                        System.out.println("Game Saved");
                        System.out.println("Returning to the previous menu...");
                        System.out.println(" ");
                        menuback = true;
                    }

                    else if (menuChoice == 3)
                    {
                        System.out.println("Returning to the previous menu...");
                        System.out.println(" ");
                        menuback = true;
                    }

                    else
                    {
                        System.out.println(" ");
                        System.out.println("Invalid choice");
                        System.out.println("Please try again");
                    }
                }

            }
            else if (ans == 3)
            {
                System.out.println(" ");
                System.out.println("Closing the game...");
                System.out.println("Thank you for playing our game!!");
                System.out.println("Have a great day!!!");
                exit = true;
                System.exit(0);
            }
        }

        if (playernumber == 2)
        {
            setup2();
        }
        else if (playernumber == 4)
        {
            setup4();
        }

    }

    /**
     * Continue the game for two players.
     * By allowing turns to be taken by each player.
     * */
    public void setup2()
    {
        int turncounter;
        turncounter = 0;

        while((turncounter<200) && (player1Score<100) && (player2Score<100))
        {
            turnPlayer2();

            turncounter += 1;

            turnPlayer1();
        }

        gameOver();
    }

    /**
     * Continue the game for four players.
     * By allowing turns to be taken by each player.
     * */
    public void setup4()
    {
        int turncounter;
        turncounter = 0;

        while((turncounter<200) && (player1Score<100) && (player2Score<100) && (player3Score<100) && (player4Score<100))
        {

            turnPlayer2();

            turnPlayer3();

            turnPlayer4();

            turncounter +=1;

            turnPlayer1();
        }

        gameOver2();

    }

    /**
     * Allows a saved game to continue.
     * It works only for two players.
     * */
    public void loadsetup2()
    {
        if (currentPlayer.equals(player1))
        {
            int turncounter;
            turncounter = 0;

            while((turncounter<200) && (player1Score<100) && (player2Score<100))
            {
                turnPlayer1();

                turnPlayer2();

                turncounter += 1;
            }

            gameOver();

        }

        else if(currentPlayer.equals(player2))
        {
            int turncounter;
            turncounter = 0;

            while((turncounter<200) && (player1Score<100) && (player2Score<100)) {
                turnPlayer2();

                turnPlayer1();

                turncounter += 1;
            }

            gameOver();
        }

    }

    /**
     * Allows a saved game to continue.
     * It works only for four players.
     * */
    public void loadsetup4()
    {
        if (currentPlayer.equals(player1))
        {
            int turncounter;
            turncounter = 0;

            while((turncounter<200) && (player1Score<100) && (player2Score<100) && (player3Score<100) && (player4Score<100))
            {
                turnPlayer1();

                turnPlayer2();

                turnPlayer3();

                turnPlayer4();

                turncounter += 1;
            }

            gameOver2();

        }

        else if(currentPlayer.equals(player2))
        {
            int turncounter;
            turncounter = 0;

            while((turncounter<200) && (player1Score<100) && (player2Score<100) && (player3Score<100) && (player4Score<100))
            {
                turnPlayer2();

                turnPlayer3();

                turnPlayer4();

                turncounter += 1;

                turnPlayer1();
            }

            gameOver2();

        }

        else if(currentPlayer.equals(player3))
        {
            int turncounter;
            turncounter = 0;

            while((turncounter<200) && (player1Score<100) && (player2Score<100) && (player3Score<100) && (player4Score<100))
            {
                turnPlayer3();

                turnPlayer4();

                turncounter += 1;

                turnPlayer1();

                turnPlayer2();
            }

            gameOver2();
        }

        else if(currentPlayer.equals(player4))
        {
            int turncounter;
            turncounter = 0;

            while((turncounter<200) && (player1Score<100) && (player2Score<100) && (player3Score<100) && (player4Score<100))
            {
                turnPlayer4();

                turncounter += 1;

                turnPlayer1();

                turnPlayer2();

                turnPlayer3();
            }

            gameOver2();
        }
    }

    /**
     * Ends the game and looks for the winner.
     * Only works for two players
     * */
    public void gameOver()
    {
        System.out.println("============================ Game Over ===============================");

        if (player1Score>=100)
        {
            System.out.println("*********************** "+player1+" won ***********************");
            System.out.println("The final Score: ");
            System.out.println(player1 +" : "+player1Score);
            System.out.println(player2 +" : "+player2Score);
            System.out.println(" ");
            System.out.println("Thank you for playing Scribble!!");
            System.out.println("Have a great day!!");

            System.exit(0);
        }
        else if(player2Score>=100)
        {
            System.out.println("*********************** "+player2+" won ***********************");
            System.out.println("The final Score: ");
            System.out.println(player1 +" : "+player1Score);
            System.out.println(player2 +" : "+player2Score);
            System.out.println(" ");
            System.out.println("Thank you for playing Scribble!!");
            System.out.println("Have a great day!!");

            System.exit(0);
        }
        else
        {
            if(player1Score>player2Score)
            {
                System.out.println("*********************** " + player1 + " won ***********************");
            }
            else if(player2Score>player1Score)
            {
                System.out.println("*********************** " + player2 + " won ***********************");
            }
            else if(player1Score==player2Score)
            {
                System.out.println("*********************** It's a tie ***********************");
            }

            System.out.println("The final Score: ");
            System.out.println(player1 +" : "+player1Score);
            System.out.println(player2 +" : "+player2Score);

            System.out.println(" ");
            System.out.println("Thank you for playing Scribble!!");
            System.out.println("Have a great day!!");

            System.exit(0);
        }

    }

    /**
     * Ends the game and looks for the winner.
     * Only works for four players
     * */
    public void gameOver2()
    {
        System.out.println("============================ Game Over ===============================");

        if (player1Score>=100)
        {
            System.out.println("*********************** "+player1+" won ***********************");
            System.out.println("The final Score: ");
            System.out.println(player1 +" : "+player1Score);
            System.out.println(player2 +" : "+player2Score);
            System.out.println(player3 +" : "+player3Score);
            System.out.println(player4 +" : "+player4Score);
            System.out.println(" ");
            System.out.println("Thank you for playing Scribble!!");
            System.out.println("Have a great day!!");

            System.exit(0);
        }
        else if(player2Score>=100)
        {
            System.out.println("*********************** "+player2+" won ***********************");
            System.out.println("The final Score: ");
            System.out.println(player1 +" : "+player1Score);
            System.out.println(player2 +" : "+player2Score);
            System.out.println(player3 +" : "+player3Score);
            System.out.println(player4 +" : "+player4Score);
            System.out.println(" ");
            System.out.println("Thank you for playing Scribble!!");
            System.out.println("Have a great day!!");

            System.exit(0);
        }
        else if(player3Score>=100)
        {
            System.out.println("*********************** "+player3+" won ***********************");
            System.out.println("The final Score: ");
            System.out.println(player1 +" : "+player1Score);
            System.out.println(player2 +" : "+player2Score);
            System.out.println(player3 +" : "+player3Score);
            System.out.println(player4 +" : "+player4Score);
            System.out.println(" ");
            System.out.println("Thank you for playing Scribble!!");
            System.out.println("Have a great day!!");

            System.exit(0);
        }
        else if(player4Score>=100)
        {
            System.out.println("*********************** "+player4+" won ***********************");
            System.out.println("The final Score: ");
            System.out.println(player1 +" : "+player1Score);
            System.out.println(player2 +" : "+player2Score);
            System.out.println(player3 +" : "+player3Score);
            System.out.println(player4 +" : "+player4Score);
            System.out.println(" ");
            System.out.println("Thank you for playing Scribble!!");
            System.out.println("Have a great day!!");

            System.exit(0);
        }
        else
        {
            if(player1Score>player2Score && player1Score>player3Score && player1Score>player4Score)
            {
                System.out.println("*********************** "+player1+" won ***********************");
            }

            else if (player2Score>player1Score && player2Score>player3Score && player2Score>player4Score)
            {
                System.out.println("*********************** "+player2+" won ***********************");

            }

            else if (player3Score>player1Score && player3Score>player4Score && player3Score>player2Score)
            {
                System.out.println("*********************** "+player3+" won ***********************");

            }

            else if (player4Score>player3Score && player4Score>player2Score && player4Score>player1Score)
            {
                System.out.println("*********************** "+player4+" won ***********************");

            }


            System.out.println("The final Score: ");
            System.out.println(player1 +" : "+player1Score);
            System.out.println(player2 +" : "+player2Score);
            System.out.println(player3 +" : "+player3Score);
            System.out.println(player4 +" : "+player4Score);

            System.out.println(" ");
            System.out.println("Thank you for playing Scribble!!");
            System.out.println("Have a great day!!");

            System.exit(0);
        }

    }


}
